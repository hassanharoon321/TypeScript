const STRIPE_PUBLISHABLE = 
//     process.env.NODE_ENV === 'production'
//   ? 'pk_live_MY_PUBLISHABLE_KEY'
//   : 
  'pk_test_51Iw2FFKl1ZAnnMNkMEtJGcvYDf19HGfk5Jns9Akj5omsZb4xfxsPyOEs3AZBi1UHnmdoL9yP3gWBpr1c1gbFRq7h00LYMbXXN5';
 
export default STRIPE_PUBLISHABLE;