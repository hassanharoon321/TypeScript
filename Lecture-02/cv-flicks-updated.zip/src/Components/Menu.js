
// import '../App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const Menu=()=> {
//   return (
// <div className="container shadow mt-5  px-5" style={{borderRadius:"10px"}}>
//     <div className="row">

// <div className="col-md-12 pt-4">
//     <ul className="sub_menu">
//     <li className="nav-item ">
//                 <h5 className=""><a href="#" className="text_gray">Headline</a></h5>
//               </li>
//               <li className="nav-item">
//               <h5 className=""><a href="#" className="text_gray">Personal</a></h5>
//               </li>
//               <li className="nav-item ">
//               <h5 className=""><a href="#" className="text_gray">Professional</a></h5>
//               </li>
//               <li className="nav-item ">
//               <h5 className=""><a href="#" className="text_gray">Qualification</a></h5>
//               </li>
//               <li className="nav-item ">
//               <h5 className=""><a href="#" className="text_gray">Key Skills</a></h5>
//               </li>
//     </ul>
//     {/* <p><span className="px-4">Karachi,Pakistan</span><span className="px-4">Karachi,Pakistan</span><span className="px-4">Karachi,Pakistan</span></p> */}

// </div>
//     </div>

// </div>

   
//   );
// }

// export default Menu;
