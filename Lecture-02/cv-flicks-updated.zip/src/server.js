const PAYMENT_SERVER_URL= 'http://localhost:3000/get-premium';
 
export default PAYMENT_SERVER_URL;